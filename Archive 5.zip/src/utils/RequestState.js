export const RequestState = {
    IDLE: 0,
    COMPLETED: 1,
    ERROR: 2
}