import { AppImages } from "../Asset/images/image";
const images = AppImages;
const Lead = [
  {
    type: "text",
    message: "Hi I want to buy 3 Kanal plot C Block, DHA-Phase 6",
    createdAt: "11:18 PM 20 July, 2023",
    phone: "0330 5345346",
    id: "p1",
  },
  {
    type: "text",
    message: "Hi I want to buy 10 Marla House in Z Block, DHA-3",
    createdAt: "11:32 PM 20 July, 2023",
    phone: "0330 5345346",
    id: "p2",
  },
  {
    type: "text",
    message: "Hi I want to buy 10 Marla plot in DHA 9 Prism",
    createdAt: "11:36 PM 20 July, 2023",
    phone: "0330 5345346",
    id: "p3",
  },
  // {
  //   message: "10 Marla File required of DHA 10",
  //   createdAt: "11:22 PM 14 July, 2023",
  //   phone: "0330 5345346",
  //   id: "p4",
  // },
];

export default Lead;
