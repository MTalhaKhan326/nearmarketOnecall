import { AppImages } from "../Asset/images/image";
const images = AppImages;
const Plot = [
  {
    title: "3 Kanal plot required in C Block, DHA-6",
    time: "11:18 PM 15 July, 2023",
    phone: "0330 5345346",
    id: "p1",
  },
  {
    title: "10 Marla House required in Z Block, DHA-3",
    time: "11:32 PM 15 July, 2023",
    phone: "0330 5345346",
    id: "p2",
  },
  {
    title: "10 Marla plot required in DHA 9 Prism",
    time: "11:36 PM 15 July, 2023",
    phone: "0330 5345346",
    id: "p3",
  },
  // {
  //   title: "10 Marla File required of DHA 10",
  //   time: "11:22 PM 14 July, 2023",
  //   phone: "0330 5345346",
  //   id: "p4",
  // },
];

export default Plot;
