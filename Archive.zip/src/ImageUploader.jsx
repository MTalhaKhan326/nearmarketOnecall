// src/ImageUploaderr.js
import React, { useState } from "react";
import { storage } from "./firebase";

const ImageUploaderr = () => {
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [urls, setUrls] = useState([]);

  const handleFileChange = (e) => {
    const files = e.target.files;
    setSelectedFiles([...selectedFiles, ...files]);
  };

  const handleUpload = async () => {
    console.log("selected Files",selectedFiles)
    const promises = selectedFiles.map((file) => {
      const uploadTask = storage.ref(`images/${file.name}`).put(file);

      return new Promise((resolve, reject) => {
        uploadTask.on("state_changed", null, reject, () => {
          // After successful upload, get the download URL
          uploadTask.snapshot.ref
            .getDownloadURL()
            .then((downloadURL) => {
              resolve(downloadURL);
            })
            .catch(reject);
        });
      });
    });

    try {
      const urls = await Promise.all(promises);
      setUrls(urls);
      console.log(urls); // Display the URLs in the console
    } catch (error) {
      console.error("Error uploading images: ", error);
    }
  };

  return (
    <div>
      <input type="file" multiple onChange={handleFileChange} />
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default ImageUploaderr;
