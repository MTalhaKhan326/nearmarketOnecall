// // src/firebase.js
import firebase from "firebase/compat/app";
import "firebase/compat/storage";

const firebaseConfig = {
  // Replace these with your Firebase project config
  apiKey: "AIzaSyATBfNLiYtyA5CYzl2L-Y9Yc-LUSnGcCQM",
  authDomain: "http://one-call-59851.firebaseapp.com",
  projectId: "one-call-59851",
  storageBucket: "http://one-call-59851.appspot.com",
  messagingSenderId: "962461584827",
  appId: "1:962461584827:web:3a97dc0d54c4e5006e889e",
};

firebase.initializeApp(firebaseConfig);

const storage = firebase.storage();

export { storage, firebase as default };
